'use client'

import Link from 'next/link';
import { redirect, useRouter } from 'next/navigation';

export default function Page() {

    const router = useRouter();

    return (
        <div
            style={{
                display: 'flex',
                gap: '1rem'
            }}
        >
            <Link href="/suspense-ssr">Suspense Link</Link>

            <div
                onClick={() => {
                    router.replace(`/suspense-ssr?reload=${Date.now()}`);
                }}

                style={{
                    cursor: 'pointer'
                }}
            >
                Suspense Refresh
            </div>

            <div
                onClick={() => router.replace('/client-fetch')}
                style={{
                    cursor: 'pointer'
                }}
            >
                Client
            </div>
        </div>
    );
}