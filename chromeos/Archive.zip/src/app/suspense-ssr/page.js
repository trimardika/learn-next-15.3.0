import { Suspense } from 'react';
import Post from './post';
import HeaderMenu from '../components/headerMenu';
import RefreshButton from '../components/refreshButton';

export default function Page() {

    return (
        <div>
            <HeaderMenu />

            <h1>Daftar Postingan</h1>

            <RefreshButton />

            <Suspense fallback={<p>Loading posts...</p>}>
                <Post />
            </Suspense>
        </div>
    );
}