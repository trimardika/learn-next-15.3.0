function delay(ms) {
    return new Promise((res) => setTimeout(res, ms));
}

async function getPosts() {
    await delay(2000); // Simulasikan loading 2 detik

    const res = await fetch('https://jsonplaceholder.typicode.com/posts', { cache: 'no-store' });
    return res.json();
}

export default async function Post() {
    const posts = await getPosts();

    return (
        <ul>
            {posts.slice(0, 5).map((post) => (
                <li key={post.id}>{post.title}</li>
            ))}
        </ul>
    );
}