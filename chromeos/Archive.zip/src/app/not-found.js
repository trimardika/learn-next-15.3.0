const NotFound = () => {
    return (
        <div>Halaman tidak ditemukan</div>
    )
}

export default NotFound;