import { Suspense } from 'react';
import Post from './post';
import HeaderMenu from '../components/headerMenu';

export default function Page() {
    return (
        <div>
            <HeaderMenu />

            <h1>Daftar Postingan</h1>

            <Suspense fallback={<p>Loading posts...</p>}>
                <Post key={Date.now()} />
            </Suspense>
        </div>
    );
}