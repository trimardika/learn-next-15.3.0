import HeaderMenu from './components/headerMenu';

export default function Page() {
  return (
    <div>
      <HeaderMenu />
    </div>
  );
}